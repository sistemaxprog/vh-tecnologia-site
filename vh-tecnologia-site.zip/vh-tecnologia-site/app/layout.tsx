import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title:'VH Tecnologia | Automação e Software',description:'LavaRápido Smart e LaveAccess: soluções inteligentes para negócios.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="pt-BR"><body>{children}</body></html>}
